# TeoriaDeLaInformacion
El archivo "anexo.txt" esta presente en la carpeta de cada proyecto para su referencia inmediata y evitar fallos con referencia a directorios.

TP1ejercicios1A_y_2 es el proyecto C que en su main.c contiene el codigo del ejercicio 1A y ademas todos los resultados del el ejercicio 2 (incisos A, B, C y D).

TP1ejercicios1B_y_1C es el proyecto C que en su main.c contiene el codigo del ejercicio 1 incisos B y C.

En las 2 carpetas a su vez se encuentran los archivos de salida para los distintos incisos, también se imprimen por pantalla en caso de ejecutar los main y corroborar que 
las salidas son las mismas.
