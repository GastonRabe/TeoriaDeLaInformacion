package prueba;

public class CanalInexistenteException extends Exception {

	public CanalInexistenteException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
