package modelo;

public class Frecuencia {
private double frecuencia;
	
	public Frecuencia() {
		this.frecuencia=1;
	}
	
	public void aumentaFrec() {
		this.frecuencia++;
	}

	public double getFrecuencia() {
		return frecuencia;
	}
}
